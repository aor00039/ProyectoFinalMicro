package org.example;

import java.awt.AWTException;
import java.awt.Color;
import java.awt.Rectangle;
import java.awt.Robot;
import java.awt.event.InputEvent;
import java.awt.event.KeyEvent;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;
import java.util.Random;

import javax.imageio.ImageIO;

public class AutomatizacionGuardarFoto {
    private static int hola = 0;

    public static void main(String[] args) {
        // Ruta del ejecutable de la aplicación de la cámara
        String rutaEjecutable = "ReadSerialPortWin.exe";

        // Ruta del escritorio
        String rutaEscritorio = System.getProperty("user.home") + "\\Desktop\\";

        // Iniciar la automatización
        try {
            Robot robot = new Robot();
            while (true) {
                // Abrir la aplicación de la cámara
                Process proceso = Runtime.getRuntime().exec(rutaEjecutable);

                // Mover el ratón al botón "Start"
                robot.mouseMove(842, 350);
                robot.delay(1000);

                // Simular clic en el botón "Start"
                robot.mousePress(java.awt.event.InputEvent.BUTTON1_DOWN_MASK);
                robot.mouseRelease(java.awt.event.InputEvent.BUTTON1_DOWN_MASK);
                robot.delay(15000); // Esperar 15 segundos antes de comenzar a capturar imágenes

                // Comenzar a capturar imágenes cada 5 segundos
                int intervaloCaptura = 7000; // 5 segundos
                while (true) {
                    // Simular clic en el botón de guardar
                    robot.mouseMove(POSICION_X_DEL_BOTON_GUARDAR, POSICION_Y_DEL_BOTON_GUARDAR);
                    robot.delay(1000);
                    robot.mousePress(java.awt.event.InputEvent.BUTTON1_DOWN_MASK);
                    robot.mouseRelease(java.awt.event.InputEvent.BUTTON1_DOWN_MASK);
                    robot.delay(2000); // Esperar 2 segundos para que aparezca la ventana emergente

                    // Generar un nombre aleatorio para la imagen
                    String nombreImagen = generarNombreAleatorio();

                    // Simular la escritura del nombre en la ventana emergente
                    for (char c : nombreImagen.toCharArray()) {
                        int keyCode = KeyEvent.getExtendedKeyCodeForChar(c);
                        robot.keyPress(keyCode);
                        robot.keyRelease(keyCode);
                        robot.delay(100); // Pequeña pausa entre pulsaciones para evitar problemas
                    }

                    // Simular la tecla "Enter" para aceptar la ventana emergente
                    robot.keyPress(KeyEvent.VK_ENTER);
                    robot.keyRelease(KeyEvent.VK_ENTER);

                    // Esperar el intervalo de tiempo antes de la próxima captura
                    Thread.sleep(intervaloCaptura);
                }
            }
        } catch (AWTException | InterruptedException | IOException e) {
            e.printStackTrace();
        }
    }

    // Generar un nombre aleatorio para la imagen
    private static String generarNombreAleatorio() {
        Random rand = new Random();
        int num = hola++;
        return "imagen" + num + ".bmp";
    }

    // Ajustar las siguientes constantes según tu aplicación y pantalla
    private static final int POSICION_X_DEL_BOTON_GUARDAR = 895;
    private static final int POSICION_Y_DEL_BOTON_GUARDAR = 409;
    private static final int POSICION_X_DEL_CAMBIO_VISUAL = 300;
    private static final int POSICION_Y_DEL_CAMBIO_VISUAL = 400;
    private static final int ANCHO_CAMBIO_VISUAL = 1;
    private static final int ALTO_CAMBIO_VISUAL = 1;




}
