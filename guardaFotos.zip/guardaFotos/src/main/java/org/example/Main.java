package org.example;

//import org.apache.commons.io.FileUtils;

import net.coobird.thumbnailator.Thumbnails;
import org.apache.commons.io.FileUtils;
import org.apache.commons.codec.binary.Hex;

import java.awt.*;
import java.awt.event.InputEvent;
import java.awt.event.KeyEvent;
import java.awt.image.BufferedImage;
import java.io.*;
import java.util.*;

import com.fazecast.jSerialComm.SerialPort;
import javax.imageio.ImageIO;
public class Main {
    private static int hola = 0;
    public static void main(String[] args) {
// Ruta del ejecutable de la aplicación de la cámara
        String rutaEjecutable = "ReadSerialPortWin.exe";

        // Ruta del escritorio
        String rutaEscritorio = System.getProperty("user.home") + "\\Desktop\\";

//        SerialPort commPort = SerialPort.getCommPort("COM9");
//        commPort.setComPortTimeouts(SerialPort.TIMEOUT_WRITE_BLOCKING, 0, 0);

//        try{
//            boolean opened = commPort.openPort();
//            System.out.println("Port opened: " + opened);
//        }catch (Exception e){
//            System.out.println(e);;
//        }

        // Iniciar la automatización
        try {
            Robot robot = new Robot();
            while (true) {
                // Abrir la aplicación de la cámara
                Process proceso = Runtime.getRuntime().exec(rutaEjecutable);

                // Mover el ratón al botón "Start"
                robot.mouseMove(1000, 450);
                robot.delay(1000);

                // Simular clic en el botón "Start"
                robot.mousePress(java.awt.event.InputEvent.BUTTON1_DOWN_MASK);
                robot.mouseRelease(java.awt.event.InputEvent.BUTTON1_DOWN_MASK);
                robot.delay(15000); // Esperar 15 segundos antes de comenzar a capturar imágenes

                // Comenzar a capturar imágenes cada 5 segundos
                int intervaloCaptura = 7000; // 5 segundos
                while (true) {
                    // Simular clic en el botón de guardar
                    System.out.println("Click guardar");
                    robot.mouseMove(POSICION_X_DEL_BOTON_GUARDAR, POSICION_Y_DEL_BOTON_GUARDAR);
                    robot.delay(1000);
                    robot.mousePress(java.awt.event.InputEvent.BUTTON1_DOWN_MASK);
                    robot.mouseRelease(java.awt.event.InputEvent.BUTTON1_DOWN_MASK);
                    robot.delay(2000); // Esperar 2 segundos para que aparezca la ventana emergente


                    // Generar un nombre aleatorio para la imagen
                    String nombreImagen = generarNombreAleatorio();
                    System.out.println("Escribiendo nombre imagen");
                    // Simular la escritura del nombre en la ventana emergente
                    for (char c : nombreImagen.toCharArray()) {
                        int keyCode = KeyEvent.getExtendedKeyCodeForChar(c);
                        robot.keyPress(keyCode);
                        robot.keyRelease(keyCode);
                        robot.delay(100); // Pequeña pausa entre pulsaciones para evitar problemas
                    }

                    // Simular la tecla "Enter" para aceptar la ventana emergente
                    robot.keyPress(KeyEvent.VK_ENTER);
                    robot.keyRelease(KeyEvent.VK_ENTER);
                    robot.delay(2000);

                    Thread.sleep(5000);

                    String rutaImagen = "C:\\Users\\Alvaro\\Documents\\"+nombreImagen;

                    // Reducir tamaño imagen para comprimir
                    String resizedFileName= "";
                    try {
                        BufferedImage original = ImageIO.read(new File(rutaImagen));
                        BufferedImage resized = resizeImage(original, 200, 200);

                        resizedFileName = "C:\\Users\\Alvaro\\Documents\\resized_"+nombreImagen+".jpg";
                        File outputFile = new File(resizedFileName);
                        ImageIO.write(resized, "JPG", outputFile);
                        System.out.println("Resized file created");
                    }catch(Exception e){
                        System.out.println(e);
                    }


                    System.out.println(resizedFileName);
                    String b64Encoded = "";
                    String hexEncoded = "";
                    try {
                        byte[] fileContent = FileUtils.readFileToByteArray(new File(resizedFileName));
                        b64Encoded = Base64.getEncoder().encodeToString(fileContent);
                        hexEncoded = Hex.encodeHexString(b64Encoded.getBytes());
                    } catch (Exception e){
                        System.out.println(e);
                    }

                    System.out.println("Encoded: ");
                    System.out.println(hexEncoded);
                    String rutaArchivo = "C:\\Usuarios\\Alvaro\\Documents\\"+generarNombreB64();


                    // Manda datos a través del puerto serie
                    String puertoSerial = "COM9";
                    SerialPort thePort = SerialPort.getCommPort("COM9");
                    thePort.openPort();

//                    if (waitForAuthorization(thePort) != -1) {
                    if (1 ==1){
                        System.out.println("Proceso autorizado. Se procede a mandar datos...");
                        try {
                            //Using jSerialComm
                            SerialPort[] device_ports = SerialPort.getCommPorts();
//                            SerialPort thePort = SerialPort.getCommPort(puertoSerial);
//                            SerialPort thePort = commPort;
//                            boolean flushed = thePort.flushIOBuffers();
//                            thePort.clearDTR();
//                            thePort.clearRTS();
                            thePort.setComPortTimeouts(SerialPort.TIMEOUT_WRITE_BLOCKING, 0,0 );
//                            System.out.println("Buffers flushed: " + flushed);
                            thePort.setBaudRate(9600);
                            boolean opened = thePort.isOpen();
                            System.out.println("Opened: " + opened);
//                            for (SerialPort each : device_ports) {
//                                System.out.println("Port: " + each.getSystemPortName());
//                            }

                            // Obtener el flujo de salida del puerto serie
                            OutputStream outputStream = thePort.getOutputStream();
//                            outputStream.flush();

                            // Bytes que deseas enviar
                            byte[] bytesToSend = hexEncoded.getBytes();
                            byte[] packetLength = String.valueOf(bytesToSend.length).getBytes();
                            System.out.println("Se van a mandar " + bytesToSend.length + " bytes ");

                            int nDiv = 10;
                            ArrayList<byte[]> packets = new ArrayList<>(nDiv);
                            int tam = bytesToSend.length/nDiv;
                            System.out.println("Se van a crear " + nDiv + "packetes de " + tam + "bytes");
                            // Dividir el array en partes
                            for (int i = 0; i < nDiv; i++) {
                                int startIndex = i * tam;
                                int endIndex = (i + 1) * tam;

                                // Manejar el último segmento si el tamaño no es divisible uniformemente
                                if (i == nDiv - 1) {
                                    endIndex = bytesToSend.length;
                                }

                                // Copiar la parte del array en una nueva array
                                byte[] subArray = Arrays.copyOfRange(bytesToSend, startIndex, endIndex);

                                // Puedes imprimir o procesar la subArray según tus necesidades
                                System.out.println("Subarray " + (i + 1) + ": " + subArray.length + " bytes");
                                packets.add(subArray);
                            }

                            // Enviar los bytes en paquetes
                            for (int i = -1; i < nDiv; i++){
                                if (i==-1){
                                    outputStream.write(String.valueOf(nDiv).getBytes());
                                    System.out.println("Se manda el numero de paquetes");
                                    thePort.setComPortTimeouts(SerialPort.TIMEOUT_READ_BLOCKING, 5000, 0);
                                    InputStream inputStream = thePort.getInputStream();
                                    Thread.sleep(3000);
                                    inputStream.read(); // Wait for confirmation
                                    System.out.println("Confirmation recibida! Se comienza el envio");
                                    inputStream.close();
                                }else{

                                    outputStream.write(packets.get(i));
                                    System.out.println("Paquete-" + i + "- Bytes enviados con éxito.");

                                    thePort.setComPortTimeouts(SerialPort.TIMEOUT_READ_BLOCKING, 0, 0);
                                    InputStream inputStream = thePort.getInputStream();
                                    Thread.sleep(2000);
                                    inputStream.read(); // Wait for confirmation
                                    System.out.println("Confirmation recibida! Se continua el envio");
                                    inputStream.close();
                                }
                            }
//                            outputStream.write(bytesToSend);
////                            System.out.println("MENSAJE: "+ bytesToSend);
//                            System.out.println("Bytes enviados con éxito.");
//
                            // Cerrar el flujo de salida y el puerto serie
//                            outputStream.close();
//
//                            Thread.sleep(2000);
//                            thePort.setComPortTimeouts(SerialPort.TIM, 0, 0);


//                            thePort.setComPortTimeouts(SerialPort.TIMEOUT_READ_BLOCKING, 0, 0);
//                            InputStream inputStream = thePort.getInputStream();
//                            byte[] arrBytes = inputStream.readNBytes(5);
//                            System.out.print("Mensaje recibido!: ");
//                            System.out.println(Arrays.toString(arrBytes));
//
//                            inputStream.close();

//                            thePort.closePort();
//
                        } catch (Exception e) {
                            e.printStackTrace();
                        }
                    }else{
                        System.out.println("No se ha autorizado el envio de datos desde Arduino");
                    }
                    thePort.closePort();


                    // Esperar el intervalo de tiempo antes de la próxima captura
                    Thread.sleep(intervaloCaptura);
                }
            }
        } catch (AWTException | InterruptedException | IOException e) {
            e.printStackTrace();
        }

//        commPort.closePort();
    }
    private static String generarNombreAleatorio() {
        Random rand = new Random();
        int num = hola;
        return "imagen" + num + ".bmp";
    }
    private static String generarNombreB64(){

        return "imagen"+(hola++)+".b64";
    }

    private static BufferedImage resizeImage(BufferedImage originalImage, int targetWidth, int targetHeight) throws Exception {
        ByteArrayOutputStream outputStream = new ByteArrayOutputStream();
        Thumbnails.of(originalImage)
                .size(targetWidth, targetHeight)
                .outputFormat("JPG")
                .outputQuality(0.7)
                .toOutputStream(outputStream);
        byte[] data = outputStream.toByteArray();
        ByteArrayInputStream inputStream = new ByteArrayInputStream(data);
        return ImageIO.read(inputStream);
    }

    private static int waitForAuthorization(SerialPort puertoSerial){
        int toRet = -1;
        //Using jSerialComm
        SerialPort[] device_ports = SerialPort.getCommPorts();
//        SerialPort thePort = SerialPort.getCommPort(puertoSerial);
        SerialPort thePort = puertoSerial;

        thePort.setBaudRate(9600);
        boolean opened = thePort.isOpen();
        System.out.println("Is opened: " + opened);

        //Recibe mensaje a través del puerto serie
        try {
            System.out.println("Recibiendo mensajes ....");


            // Obtener el flujo de salida del puerto serie
            thePort.setComPortTimeouts(SerialPort.TIMEOUT_READ_BLOCKING, 2000, 0);
            InputStream inputStream = thePort.getInputStream();

            toRet = inputStream.read(); // Recieve char from inputStream
            System.out.println("Se han leido " + toRet + " bytes");
            inputStream.readAllBytes();
            inputStream.reset();


//            inputStream.close();
//            thePort.closePort();

            Thread.sleep(2000);

//            thePort.closePort();

            return toRet;
//
        } catch (Exception e) {
            System.out.println(e);
            thePort.closePort();
            return toRet;
        }
    }

    // Ajustar las siguientes constantes según tu aplicación y pantalla
    private static final int POSICION_X_DEL_BOTON_GUARDAR = 1000;
    private static final int POSICION_Y_DEL_BOTON_GUARDAR = 510;

    private static final int POSICION_X_CAJA = 910;
    private static final int POSICION_Y_CAJA = 870;
    private static final int POSICION_X_DEL_CAMBIO_VISUAL = 300;
    private static final int POSICION_Y_DEL_CAMBIO_VISUAL = 400;
    private static final int ANCHO_CAMBIO_VISUAL = 1;
    private static final int ALTO_CAMBIO_VISUAL = 1;
}